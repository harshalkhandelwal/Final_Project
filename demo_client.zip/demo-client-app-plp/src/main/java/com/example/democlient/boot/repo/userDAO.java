package com.example.democlient.boot.repo;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.democlient.boot.beans.Admin;
import com.example.democlient.boot.beans.Customer;
import com.example.democlient.boot.beans.Merchant;
import com.example.democlient.boot.beans.User;




//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO 
{
    public void createCustomer(Customer user);
	public void createMerchant(Merchant mer);
	public boolean validateUser(User user);
	public void createUser(User user);
	public Admin getAdminByEmail(String email);
	public Merchant getMerchantByEmail(String email);
	public Customer getCustomerByEmail(String email);
	public void changePassword(User user);
	public String forgetEmail(String email);

}