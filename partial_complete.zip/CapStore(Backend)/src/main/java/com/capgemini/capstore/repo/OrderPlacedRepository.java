package com.capgemini.capstore.repo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Category;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.Product;
import com.capgemini.capstore.dto.Promo;
import com.capgemini.capstore.dto.SoftDelete;



@Repository
public class OrderPlacedRepository implements IOrderPlacedRepository {

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<CartDTO> getOrderPlacedProduct() {
		
		// TODO Auto-generated method stub
		/*System.out.println("hi in cart repo");
		TypedQuery<CartDTO> query = entityManager.createQuery("select prod from CartDTO prod ", CartDTO.class); 
		List<CartDTO> list = query.getResultList();
		System.out.println("cart repo list:"+list);*/
		List<CartDTO> list=new ArrayList<CartDTO>();
	/*	Customer customer=new Customer(1,"Devesh","hutiya@gmail.com","7408323225","369 basat","2388") ;
		Merchant merchant=new Merchant(1,"ramesh","ramesh@gmail.com","3456789021","Address","NewStore");
		Category category=Category.Electronics;
		Product product =new Product(1,merchant,"Solo name","img",category,"Reebok shoes","model","producttype","product feature",2000,10);
		Date date=new Date();
		SoftDelete softdelete=SoftDelete.Activated;
		Promo promo=new Promo("promocode",500,date,softdelete);
		list.add(new CartDTO(1,customer,product,merchant,2,2000,promo,softdelete));*/
		return list;
	}

}
