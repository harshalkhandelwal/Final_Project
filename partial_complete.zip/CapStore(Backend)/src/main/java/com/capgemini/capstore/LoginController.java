package com.capgemini.capstore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dto.Admin;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.User;
import com.capgemini.capstore.repo.userDAO;

@RestController
public class LoginController {

	@Autowired
	userDAO userDAO;

	
	
	@RequestMapping(method = RequestMethod.POST, value = "/validateuser")
	public User validateUser(@RequestBody User user, HttpServletRequest request) {
		HttpSession session = null;
		System.out.println("validate Server");
		User flag = userDAO.validateUser(user);
		/*
		 * if (flag != null) { return user; } else return null;
		 */return flag;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/merchantemail/{email}")
	public Merchant merchantEmail(@PathVariable("email") String email) {
		Merchant a = userDAO.getMerchantByEmail(email);
		return a;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customeremail/{email}")
	public Customer customerEmail(@PathVariable("email") String email) {
		Customer a = userDAO.getCustomerByEmail(email);
		return a;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/adminemail/{email}")
	public Admin adminEmail(@PathVariable("email") String email) {
		Admin a = userDAO.getAdminByEmail(email);
		return a;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveMerchant")
	public void saveMerchant(@RequestBody Merchant mer) {

		userDAO.createMerchant(mer);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveCustomer")
	public void saveCustomer(@RequestBody Customer cust) {
		System.out.println("inside back save" + cust);
		userDAO.createCustomer(cust);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveUser")
	public void saveUser(@RequestBody User user) {
		userDAO.createUser(user);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/form/{mail}")
	public String forget(@PathVariable("mail") String email) {
		String s = userDAO.forgetEmail(email);
		return s;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/changepass")
	public boolean change(@RequestBody User user /* @PathVariable("newpass") String newpassword */) {
		System.out.println("hello" + user.getEmailId() + user.getPassword());
		return userDAO.checkUserExist(user);
		//System.out.println(newpassword);
		// userDAO.changePassword(user);
	

	}
	@RequestMapping(method = RequestMethod.POST, value = "/updatepass")
	public void updatepass(@RequestBody User user) {
		System.out.println("hello" + user.getEmailId() + user.getPassword());
	  userDAO.updateUserPass(user);
		//System.out.println(newpassword);
		// userDAO.changePassword(user);
	

	}


}
