package com.capgemini.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.dto.Product;


@Repository
@Transactional
public class ProductRepository implements IProductRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		TypedQuery<Product> query = entityManager.createQuery("select prod from Product prod ", Product.class); 
		List<Product> list = query.getResultList();
		return list;
	}

	@Override
	public List<Product> sortPriceLowToHigh() {
		// TODO Auto-generated method stub
		System.out.println("hi i am in sortLow method");
		TypedQuery<Product> query = entityManager
				.createQuery("select prod from Product prod order by prod.productPrice asc", Product.class); 

		List<Product> list = query.getResultList();
		System.out.println("sort price low " + list);
		return list;
	}

	@Override
	public List<Product> sortPriceHighToLow() {
		// TODO Auto-generated method stub
		System.out.println("hi i am in sortHigh method");

		TypedQuery<Product> query = entityManager.createQuery("select prod from Product prod order by prod.productPrice desc", Product.class);
		List<Product> list = query.getResultList();
		System.out.println("sort price high" + list);
		return list;
	}

	@Override
	public List<Product> getSearch(String search) {
		// TODO Auto-generated method stub
		System.out.println("hi i am in search method");
		// TODO Auto-generate`d method stub
		System.out.println(search);
		TypedQuery<Product> query = entityManager.createQuery(
				"select prod from Product prod where prod.productName =:ad or prod.productBrand=:ad or prod.productType=:ad",
				Product.class); // for retrieving the data from table
		query.setParameter("ad", search);
		List<Product> list = query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public List<Product> single(int idd) {
		// TODO Auto-generated method stub
		System.out.println("hi i am in single method");
		TypedQuery<Product> query = entityManager.createQuery("select prod from Product prod  where prod.productId =:ad ",
				Product.class); // for retrieving the data from table
		query.setParameter("ad", idd);
		List<Product> list = query.getResultList();
		System.out.println("single method list" + list);
		return list;
	}
}
