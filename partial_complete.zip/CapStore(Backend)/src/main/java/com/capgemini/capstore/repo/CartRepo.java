package com.capgemini.capstore.repo;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Product;



@Repository
public interface CartRepo extends JpaRepository<CartDTO, Integer>{

	@Query("SELECT m FROM CartDTO m WHERE m.customer =:customer")
	public List<CartDTO> findCartDTOsByCustomer(@Param("customer")Customer customer);

	@Query("SELECT m FROM CartDTO m WHERE m.customer =:customer AND m.product =:product")
	public CartDTO findByCustomerAndProduct(@Param("customer")Customer customer,@Param("product")Product product);

	/*@Query("DELETE FROM CartDTO m WHERE m.id =:id")
	public void deleteById(@Param("id")int id);
	*/
	@Modifying
	@Transactional
	@Query("delete from CartDTO t where t.id =:id ")
	void delete(@Param("id")int id);

	@Modifying
	@Transactional
	@Query("update CartDTO t SET t.quantity=:q where t.id =:id ")
	public void updateQuantity(@Param("id")int id,@Param("q") int q);
	
	/*@Modifying
	@Transactional
	@Query("delete FROM CartDTO m WHERE m.customer =:customer AND m.product =:product")
	public void deleteByCustomerAndProduct(@Param("customer")Customer customer,@Param("product")Product product);
*/
}
