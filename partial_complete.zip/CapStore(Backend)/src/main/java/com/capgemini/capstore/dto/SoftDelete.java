package com.capgemini.capstore.dto;

public enum SoftDelete {
	Activated, Deactivated
}
