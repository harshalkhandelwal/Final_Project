package com.paypal.paymentPaypal.bean;

public class Wishlist {

	private int id;
	private Customer customer;
	private Product product;
	private Merchant merchant;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public int getId() {
		return id;
	}
}
