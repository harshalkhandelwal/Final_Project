package com.paypal.paymentPaypal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.paypal.paymentPaypal.setup.PayPalConfig;

@Service("payPalService")
public class PayPalServiceImpl implements PayPalService{
    
	@Autowired
	private Environment environment;
	
	@Override
	public PayPalConfig getPayPalConfig() {
		PayPalConfig payPalConfig=new PayPalConfig();
		payPalConfig.setAuthToken(environment.getProperty("paypal.authtoken"));
		payPalConfig.setBuisness(environment.getProperty("paypal.buisness"));
		payPalConfig.setPosturl(environment.getProperty("paypal.posturl"));
		payPalConfig.setReturnurl(environment.getProperty("paypal.returnurl"));
		/*System.out.println(payPalConfig.getAuthToken());
		System.out.println(payPalConfig.getBuisness());
		System.out.println(payPalConfig.getPosturl());
		System.out.println(payPalConfig.getReturnurl());*/
		return payPalConfig;
	}

}
