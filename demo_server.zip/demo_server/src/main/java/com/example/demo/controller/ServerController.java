package com.example.demo.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.bean.Admin;
import com.example.demo.bean.Customer;
import com.example.demo.bean.Merchant;
import com.example.demo.bean.User;
import com.example.demo.repo.userDAO;

@Controller
@RequestMapping("/controller")
public class ServerController {

	@Autowired
	userDAO userDAO;


	@RequestMapping(method = RequestMethod.POST, value = "/validateuser")
	public User validateUser(@ModelAttribute("userlogin") User user, HttpServletRequest request) {
		HttpSession session=null;
		boolean flag = userDAO.validateUser(user);
		if (flag) {
			return user;
		}
		else
		return null;

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/merchantemail/{email}")
	public Merchant merchantEmail(@PathVariable("email")String email){
		Merchant a = userDAO.getMerchantByEmail(email);
		return a;
	}
	@RequestMapping(method = RequestMethod.GET, value = "/customeremail/{email}")
	public Customer customerEmail(@PathVariable("email")String email){
		Customer a = userDAO.getCustomerByEmail(email);
		return a;
	}
	@RequestMapping(method = RequestMethod.GET, value = "/adminemail/{email}")
	public Admin adminEmail(@PathVariable("email")String email){
		Admin a = userDAO.getAdminByEmail(email);
		return a;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/registerMerchant")
	public String registerMerchant() {
		// RestTemplate restTemplate = new RestTemplate();
		// userDAO.save(user);
		return "registerMerchant";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveMerchant")
	public void saveMerchant(@RequestBody Merchant mer) {

		userDAO.createMerchant(mer);
		}


	@RequestMapping(method = RequestMethod.POST, value = "/saveCustomer")
	public void saveCustomer(@RequestBody Customer cust) {
				userDAO.createCustomer(cust);
			}
	
	public void saveUser(@RequestBody User user)
	{
		userDAO.createUser(user);
	}

	

	@RequestMapping(method = RequestMethod.POST, value = "/form/{mail}")
	public String forget(@RequestParam("mail")String email) {
		String s=userDAO.forgetEmail(email);
		return s;}
		
	
	@RequestMapping(method = RequestMethod.POST, value = "/changepass")
	public String change(@ModelAttribute("change") User user) {
		System.out.println("hello"+user);
		userDAO.changePassword(user);
		
		
		return "password changed";
	}


}

